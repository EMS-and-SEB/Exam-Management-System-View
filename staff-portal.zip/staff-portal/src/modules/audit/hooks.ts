import { useQuery } from '@tanstack/react-query';
import { auditApi } from './api';

export function useAuditLog(userId: string, params: { page: number; limit: number }) {
  return useQuery({
    queryKey: ['audit', userId, params],
    queryFn: () => auditApi.listForUser(userId, params),
    enabled: !!userId,
    placeholderData: (prev) => prev,
  });
}