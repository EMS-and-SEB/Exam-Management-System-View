import { useParams } from 'react-router-dom';
import { useExam } from '@/modules/exam/hooks';
import { PageHeader } from '@/components/shared/PageHeader';
import { DataTable } from '@/components/shared/DataTable';
import { LoadingState } from '@/components/shared/LoadingState';
import { useExamResults } from './hooks';
import type { ColumnDef } from '@tanstack/react-table';
import type { ExamSessionResult } from './api';

export function ExamResultsPage() {
  const { id } = useParams<{ id: string }>();
  const examId = id!;

  const { data: exam } = useExam(examId);
  const { data: results, isLoading } = useExamResults(examId);

  const columns: ColumnDef<ExamSessionResult, unknown>[] = [
    {
      id: 'student',
      header: 'Student',
      cell: ({ row }) => (
        <div>
          <p className="font-medium">{row.original.student.name}</p>
          <p className="text-xs text-muted-foreground">{row.original.student.studentId}</p>
        </div>
      ),
    },
    { id: 'auto', header: 'Auto', cell: ({ row }) => row.original.autoScore },
    { id: 'manual', header: 'Manual', cell: ({ row }) => row.original.manualScore },
    {
      id: 'total',
      header: 'Total',
      cell: ({ row }) => (
        <span className="font-medium">{row.original.totalScore} / {row.original.maxScore}</span>
      ),
    },
  ];

  return (
    <div>
      <PageHeader title={exam?.title ?? 'Results'} backTo="/results" subtitle={exam?.course?.name ?? exam?.cohort?.name} />
      {isLoading ? <LoadingState label="Loading results..." /> : (
        <DataTable columns={columns} data={results ?? []} emptyMessage="No submissions." />
      )}
    </div>
  );
}