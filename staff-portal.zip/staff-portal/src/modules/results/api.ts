import { http } from '@/lib/axios';

export interface ExamResultSummary {
  id: string;
  title: string;
  examType: string;
  status: 'CLOSED';
  closedAt: string;
  studentCount: number;
  maxScore: number;
  courseId: string | null;
  cohortId: string | null;
  courseName?: string;
  cohortName?: string;
}

interface CombinedResultRow {
  studentId: string;
  name: string;
  scores: Record<string, { score: number; maxScore: number } | null>; // keyed by examId
  aggregate: number;
  average: number;
}

export interface ExamSessionResult {
  studentId: string;
  student: { studentId: string; name: string };
  autoScore: number;
  manualScore: number;
  totalScore: number;
  maxScore: number;
}

export const resultsApi = {
  listClosedExams: () => http.get<ExamResultSummary[]>('/exams').then((r) => r.data.filter((e) => e.status === 'CLOSED')),

  getExamResults: (examId: string) =>
    http.get<ExamSessionResult[]>(`/exams/${examId}/sessions`).then((r) => r.data),

  getCourseResults: (courseId: string) =>
    http.get<CombinedResultRow[]>(`/courses/${courseId}/results`).then((r) => r.data),

  getCohortResults: (cohortId: string) =>
    http.get<CombinedResultRow[]>(`/cohorts/${cohortId}/results`).then((r) => r.data),

  exportUrl: (parent: { courseId?: string; cohortId?: string }) =>
    parent.courseId ? `/courses/${parent.courseId}/results/export` : `/cohorts/${parent.cohortId}/results/export`,

  listClosedExamsForParent: (parent: { courseId?: string; cohortId?: string }) => {
    const path = parent.courseId ? `/courses/${parent.courseId}/exams` : `/cohorts/${parent.cohortId}/exams`;
    return http.get<ExamResultSummary[]>(path).then((r) => r.data.filter((e) => e.status === 'CLOSED'));
    },
};

export const downloadResultsCsv = async (parent: { courseId?: string; cohortId?: string }) => {
  const response = await http.get(resultsApi.exportUrl(parent), { responseType: 'blob' });
  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement('a');
  link.href = url;
  link.download = 'results.csv';
  link.click();
  window.URL.revokeObjectURL(url);
};